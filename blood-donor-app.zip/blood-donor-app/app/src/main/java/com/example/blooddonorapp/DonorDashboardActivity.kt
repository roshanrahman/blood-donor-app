package com.example.blooddonorapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DonorDashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donor_dashboard)
    }
}
